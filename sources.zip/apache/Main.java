package org.apache;


import org.apache.zookeeper.KeeperException;
import org.apache.zookeeper.ZooKeeper;

import java.io.IOException;

public class Main {

    public static void main (String[] args) throws IOException, KeeperException, InterruptedException {

        ZooKeeper zk = new ZooKeeper("192.168.9.134:2181", 1000, null);
        System.out.println(zk.getSessionId()+" "+zk.getState());
        zk.transaction().commit();
        zk.exists("/",false);
        System.out.println(zk.getSessionId()+" "+zk.getState());




    }
}
